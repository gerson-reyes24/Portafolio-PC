bash E5CASS.sh
#ApyKey para usar API Have I Been Pwned
#cfccfca8a55b497f9f3c5b22a9cd132a